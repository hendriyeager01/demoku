<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
    <!-- tap on top starts-->
    <div class="tap-top"><i data-feather="chevrons-up"></i></div>
    <!-- tap on tap ends-->
    <!-- page-wrapper Start-->
    <div class="page-wrapper compact-wrapper" id="pageWrapper">
      <!-- Page Header Start-->
      <div class="page-header">
        <div class="header-wrapper row m-0">
          <div class="header-logo-wrapper col-auto p-0">
            <div class="logo-wrapper"><a href="./home"><img class="logo" src="https://i.ibb.co/WWm4VfL/logo2-removebg-preview-1.png" alt=""></a></div>
            <div class="toggle-sidebar"><i class="status_toggle middle sidebar-toggle" data-feather="align-center"></i></div>
          </div>
          <div class="left-header col horizontal-wrapper ps-0">
            <ul class="horizontal-menu">
              <li class="level-menu outside"><a class="nav-link" href="https://anymhost.id"><i data-feather="inbox"></i><span>Hosting</span></a>
              </li>
            </ul>
          </div>
          <div class="nav-right col-8 pull-right right-header p-0">
            <ul class="nav-menus">
            
              <li>
                <div class="mode"><i class="fa fa-moon-o"></i></div>
              </li>
            
              
              <li class="onhover-dropdown">
                <div class="notification-box"><i data-feather="bell"> </i><span class="badge rounded-pill badge-secondary">3                                </span></div>
                <ul class="notification-dropdown onhover-show-div">
                  <li><i data-feather="bell"></i>
                    <h6 class="f-18 mb-0">Info</h6>
                  </li>
                  <li>
                    <p><i class="fa fa-circle-o me-3 font-primary"> </i>Welcome Mina San</p>
                  </li>
                  <li>
                    <p><i class="fa fa-circle-o me-3 font-success"></i>This Website has been published</p>
                  </li>
                  <li>
                    <p><i class="fa fa-circle-o me-3 font-info"></i>Subscribe <a href="https://youtube.com/Anympedia">AnymPedia</a></p>
                  </li>
                  <li><a class="btn btn-primary" onclick="done()">Done</a></li>
                </ul>
              </li>
              <li class="maximize"><a class="text-dark" href="#!" onclick="javascript:toggleFullScreen()"><i data-feather="maximize"></i></a></li>
          </div>
        </div>
      </div>
      <!-- Page Header Ends                              -->
      
      <!-- Page Body Start-->
      <div class="page-body-wrapper">
        <!-- Page Sidebar Start-->
        <div class="sidebar-wrapper">
          <div>
            <div class="logo-wrapper"><a href="./home"><img class="logo for-light" src="https://i.ibb.co/nPvpTFV/logo-anym-removebg-preview-2-1.png" alt=""><img class="logo for-dark" src="https://i.ibb.co/nPvpTFV/logo-anym-removebg-preview-2-1.png" alt=""></a>
              <div class="back-btn"><i class="fa fa-angle-left"></i></div>
              <div class="toggle-sidebar"><i class="status_toggle middle sidebar-toggle" data-feather="grid"> </i></div>
            </div>
            <div class="logo-icon-wrapper"><a href="./home"><img class="logo" src="https://i.ibb.co/nPvpTFV/logo-anym-removebg-preview-2-1.png" alt=""></a></div>
            <nav class="sidebar-main">
              <div class="left-arrow" id="left-arrow"><i data-feather="arrow-left"></i></div>
              <div id="sidebar-menu">
                <ul class="sidebar-links" id="simple-bar">
                  <li class="back-btn"><a href="./home"><img class="logo" src="https://i.ibb.co/nPvpTFV/logo-anym-removebg-preview-2-1.png" alt=""></a>
                    <div class="mobile-back text-end"><span>Back</span><i class="fa fa-angle-right ps-2" aria-hidden="true"></i></div>
                  </li>
                  <hr>
<li class="sidebar-list"><a class="sidebar-link sidebar-title link-nav" href="./home"><i data-feather="home"> </i><span>Home</span></a></li>
<!-- Online Tools Start -->
                  <li class="sidebar-main-title">
                    <div>
                      <h6 id="mentools">Tools Online</h6>
                      <p>Ready To Use For Free</p>
                    </div>
                  </li>
                  <li class="sidebar-list">
                    <label class="badge badge-success">4</label><a class="sidebar-link sidebar-title" href="#"><i data-feather="code"></i><span>Programming          </span></a>
                    <ul class="sidebar-submenu">
                      <li><a href="./livecoding">Live Coding</a></li>
                      <li><a href="./html-encode">HTML Encode</a></li>
                      <li><a href="./image-encoder">Image Encoder</a></li>
                      <li><a href="./php-obfuscator">PHP Obfuscator</a></li>
                    </ul>
                  </li>
                  <li class="sidebar-list">
                      <label class="badge badge-success">4</label><a class="sidebar-link sidebar-title" href="#"><i data-feather="airplay"></i><span>Network</span></a>
                    <ul class="sidebar-submenu">
                      <li><a href="./dns-lookup">DNS Lookup</a></li>
                      <li><a href="./subdomain-finder">SubDomain Finder</a></li>
                      <li><a href="./ip-geo">IP Geolocation</a></li>
                      <li><a href="./whois">Whois Lookup</a></li>
                    </ul>
                  </li>
                  <li class="sidebar-list">
                      <label class="badge badge-success">2</label><a class="sidebar-link sidebar-title" href="#"><i data-feather="slack"></i><span>Generator</span></a>
                    <ul class="sidebar-submenu">
                        <li><a href="./jso-generator">JSO Generator</a></li>
                      <li><a href="./meta-tag-generator">Meta Tag Gen</a></li>
                      
                    </ul>
                  </li>
                  
<!-- Online Tools End -->

<li class="sidebar-main-title">
                    <div>
                      <h6 id="mentools">Online Store</h6>
                      <p>Browse Our Product</p>
                    </div>
                  </li>
                  <li class="sidebar-list">
                    <label class="badge badge-success">1</label><a class="sidebar-link sidebar-title" href="#"><i data-feather="server"></i><span>Hosting</span></a>
                    <ul class="sidebar-submenu">
                      <li><a href="./cheap-hosting">Cheap Hosting</a></li>
                    </ul>
                  </li>

<!-- Defacement Archive Start
                  <li class="sidebar-main-title">
                    <div>
                        <label class="badge badge-danger"> On Going</label>
                      <h6>Archive Defacement</h6>
                      <p>Save Your Deface History</p>
                    </div>
                  </li>
                  <li class="sidebar-list">
                    <a class="sidebar-link sidebar-title" href="#"><i data-feather="box"></i><span>Rank</span></a>
                    <ul class="sidebar-submenu">
                      <li><a href="#">Team Rank</a></li>
                      <li><a href="#">Attacker Rank</a></li>
                    </ul>
                  </li>
                  <li class="sidebar-list"><a class="sidebar-link sidebar-title link-nav" href="#"><i data-feather="git-pull-request"> </i><span>Archive</span></a></li>
                  <li class="sidebar-list">  
                   <a class="sidebar-link sidebar-title link-nav" href="#"><i data-feather="monitor"> </i><span>Notify</span></a>
                  </li>
Defacement Archive end -->
                  <li class="sidebar-main-title">
                    <div>
                      <h6>Pages</h6>
                      <p>All neccesary pages added</p>
                    </div>
                  </li>
                  <li class="sidebar-list"><a class="sidebar-link sidebar-title link-nav" href="./about.php"><i data-feather="users"> </i><span>About Me</span></a></li>
                  <li class="sidebar-list"><a class="sidebar-link sidebar-title link-nav" href="./donate.php"><i data-feather="coffee"> </i><span>Donate</span></a></li>
                  <li class="sidebar-list"><a class="sidebar-link sidebar-title link-nav" href="./disclaimer.php"><i data-feather="globe"> </i><span>Disclaimer</span></a></li>
                  <li class="sidebar-list"><a class="sidebar-link sidebar-title link-nav" href="./privacy.php"><i data-feather="anchor"></i><span>Privacy Policy</span></a></li>
                  <li class="sidebar-list"><a class="sidebar-link sidebar-title link-nav" href="#"><i data-feather="sunrise"> </i><span>Knowledgebase</span></a></li>
                  <hr>
              </div>
              <div class="right-arrow" id="right-arrow"><i data-feather="arrow-right"></i></div>
            </nav>
          </div>
        </div>
        <script type="text/javascript">
                      function done()
                      {
                          Swal.fire({
  title: 'Hello!',
  icon: 'info',
  html:
  'Dont Forget To Subscribe AnymPedia<br>' + 
    '<a href="https://youtube.com/AnymPedia">Subscribe Now<a>',
  confirmButtonText: 'Okay'
})
                      }
//<![CDATA[
shortcut={all_shortcuts:{},add:function(a,b,c){var d={type:"keydown",propagate:!1,disable_in_input:!1,target:document,keycode:!1};if(c)for(var e in d)"undefined"==typeof c[e]&&(c[e]=d[e]);else c=d;d=c.target,"string"==typeof c.target&&(d=document.getElementById(c.target)),a=a.toLowerCase(),e=function(d){d=d||window.event;if(c.disable_in_input){var e;d.target?e=d.target:d.srcElement&&(e=d.srcElement),3==e.nodeType&&(e=e.parentNode);if("INPUT"==e.tagName||"TEXTAREA"==e.tagName)return}d.keyCode?code=d.keyCode:d.which&&(code=d.which),e=String.fromCharCode(code).toLowerCase(),188==code&&(e=","),190==code&&(e=".");var f=a.split("+"),g=0,h={"`":"~",1:"!",2:"@",3:"#",4:"$",5:"%",6:"^",7:"&",8:"*",9:"(",0:")","-":"_","=":"+",";":":","'":'"',",":"<",".":">","/":"?","\\":"|"},i={esc:27,escape:27,tab:9,space:32,"return":13,enter:13,backspace:8,scrolllock:145,scroll_lock:145,scroll:145,capslock:20,caps_lock:20,caps:20,numlock:144,num_lock:144,num:144,pause:19,"break":19,insert:45,home:36,"delete":46,end:35,pageup:33,page_up:33,pu:33,pagedown:34,page_down:34,pd:34,left:37,up:38,right:39,down:40,f1:112,f2:113,f3:114,f4:115,f5:116,f6:117,f7:118,f8:119,f9:120,f10:121,f11:122,f12:123},j=!1,l=!1,m=!1,n=!1,o=!1,p=!1,q=!1,r=!1;d.ctrlKey&&(n=!0),d.shiftKey&&(l=!0),d.altKey&&(p=!0),d.metaKey&&(r=!0);for(var s=0;k=f[s],s<f.length;s++)"ctrl"==k||"control"==k?(g++,m=!0):"shift"==k?(g++,j=!0):"alt"==k?(g++,o=!0):"meta"==k?(g++,q=!0):1<k.length?i[k]==code&&g++:c.keycode?c.keycode==code&&g++:e==k?g++:h[e]&&d.shiftKey&&(e=h[e],e==k&&g++);if(g==f.length&&n==m&&l==j&&p==o&&r==q&&(b(d),!c.propagate))return d.cancelBubble=!0,d.returnValue=!1,d.stopPropagation&&(d.stopPropagation(),d.preventDefault()),!1},this.all_shortcuts[a]={callback:e,target:d,event:c.type},d.addEventListener?d.addEventListener(c.type,e,!1):d.attachEvent?d.attachEvent("on"+c.type,e):d["on"+c.type]=e},remove:function(a){var a=a.toLowerCase(),b=this.all_shortcuts[a];delete this.all_shortcuts[a];if(b){var a=b.event,c=b.target,b=b.callback;c.detachEvent?c.detachEvent("on"+a,b):c.removeEventListener?c.removeEventListener(a,b,!1):c["on"+a]=!1}}},shortcut.add("Ctrl+U",function(){top.location.href="https://anym.me"});
//]]>
document.onkeydown = function(e) {
if(event.keyCode == 123) {
return false;
}
if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
return false;
}
if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
return false;
}
if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
return false;
}
}
eval(function(p,a,c,k,e,d){e=function(c){
return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('(3(){(3 a(){8{(3 b(2){7((\'\'+(2/2)).6!==1||2%5===0){(3(){}).9(\'4\')()}c{4}b(++2)})(0)}d(e){g(a,f)}})()})();',17,17,'||i|function|debugger|20|length|if|try|constructor|||else|catch||5000|setTimeout'.split('|'),0,{}))
                  </script>
