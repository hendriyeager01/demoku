<?php
$judul=@Sub_Domain_Finder;
include'tools/sec.php';
error_reporting(0);
include 'anymdata/head.php';
include 'anymdata/sidebar.php';
include 'tools/networks/sub.php';
include 'anymdata/footer.php'
?>